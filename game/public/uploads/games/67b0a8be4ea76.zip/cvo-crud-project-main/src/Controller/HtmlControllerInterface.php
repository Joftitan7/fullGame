<?php

namespace Src\Controller;

interface HtmlControllerInterface
{
    public function render(): void;
}
