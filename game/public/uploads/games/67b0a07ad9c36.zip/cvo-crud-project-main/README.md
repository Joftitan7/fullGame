# cvo-basic-structure
Download en typ "composer install" in je git bash, in dezelfde map als je dit project hebt gedownload.
