<?php

namespace Src;

class User
{
    public function __construct(public string $name)
    {
        $a =           5;
        if ($a ==           $_GET["a"]) echo "yres";


    }
}
